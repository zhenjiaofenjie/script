#!/usr/bin/perl

#Used to allot Pacbio seqs to each sample.
#Written by WangJing 2012-05-17

use strict;
use warnings;
use Getopt::Long;
use Bio::SeqIO;


my($seqfile,$tagfile)=(undef,undef);

GetOptions('sq|s=s' => \$seqfile,
	  );

my %id;
                   
my $seq_in=Bio::SeqIO->new(-file=>$seqfile,
			   -format=>"fasta", 
                          );
                                                    
while(my $seq=$seq_in -> next_seq()){
	my $name=$seq->display_name();
	$name=~ s/_[0-9]*$//;
	push(@{$id{$name}},$seq);
}


foreach my $sample(keys(%id)){
	my $seq_out=Bio::SeqIO->new(-file=>">".$sample.".fasta",
				    -format=>"fasta",
				   );
	while(${$id{$sample}}[0]){
		my $seq=shift(@{$id{$sample}});
		$seq_out->write_seq($seq);
	}
}
