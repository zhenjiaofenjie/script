#!/usr/bin/perl
 
# This is code example 4 in the Graphics-HOWTO
use strict;
use lib "$ENV{HOME}/bioperl-live";
use Bio::Graphics;
use Bio::SearchIO;
use Bio::SeqFeature::Generic;
my $file = shift or die "Usage: render_blast4.pl <blast file>\n";
 
my $searchio = Bio::SearchIO->new(-file   => $file,
                                  -format => 'blast') or die "parse failed";
my $panel = Bio::Graphics::Panel->new(
                                      -length    => 1800,
                                      -width     => 800,
                                      -pad_left  => 10,
                                      -pad_right => 10,
                                     );
while(my $result = $searchio->next_result()){
 

 
my $full_length = Bio::SeqFeature::Generic->new(
                                                -start        => 1,
                                                -end          => $result->query_length,
                                                -display_name => $result->query_name,
                                               );
$panel->add_track($full_length,
                  -glyph   => 'arrow',
                  -tick    => 2,
                  -fgcolor => 'black',
                  -double  => 1,
                  -label   => 1,
                 );
 
my $track = $panel->add_track(
                              -glyph       => 'graded_segments',
                              -label       => 1,
                              -connector   => 'dashed',
                              -bgcolor     => 'blue',
                              -font2color  => 'red',
                              -sort_order  => 'high_score',
                              -description => sub {
                                my $feature = shift;
                                return unless $feature->has_tag('description');
                                my ($description) = $feature->each_tag_value('description');
                                my $score = $feature->score;
                                "$description, score=$score";
                               },
                             );
 
while( my $hit = $result->next_hit ) {
  next unless $hit->significance < 1E-2;
  my $feature = Bio::SeqFeature::Generic->new(
                                              -score        => $hit->raw_score,
                                              -display_name => $hit->name,
                                              -tag          => {
                                                                description => $hit->description
                                                               },
                                             );
  while( my $hsp = $hit->next_hsp ) {
    $feature->add_sub_SeqFeature($hsp,'EXPAND');
  }
 
  $track->add_feature($feature);
}
}
 
print $panel->png;
